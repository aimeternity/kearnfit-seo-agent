export default async (req) => {
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return Response.json({ error: "Sign in required." }, { status: 401 });
  const wpUrl = Netlify.env.get("WP_SITE_URL");
  const wpUser = Netlify.env.get("WP_USERNAME");
  const wpPassword = Netlify.env.get("WP_APP_PASSWORD");
  const supabaseUrl = "https://cdpxmbdcqdohawnxylwt.supabase.co";
  const supabaseKey = "sb_publishable_g9mu6mPIzXqgDjFN1xvs9A_PmAArrcE";
  if (!wpUrl || !wpUser || !wpPassword) return Response.json({ error: "WordPress connection settings are incomplete." }, { status: 503 });
  const authCheck = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: supabaseKey, Authorization: `Bearer ${token}` } });
  if (!authCheck.ok) return Response.json({ error: "Your session is invalid. Please sign in again." }, { status: 401 });
  try {
    const credentials = Buffer.from(`${wpUser}:${wpPassword}`).toString("base64");
    const response = await fetch(`${wpUrl.replace(/\/$/, "")}/wp-json/wp/v2/users/me?context=edit`, { headers: { Authorization: `Basic ${credentials}`, Accept: "application/json" } });
    if (!response.ok) return Response.json({ error: "WordPress did not accept the connection. Check the dedicated user's Application Password and role." }, { status: 502 });
    const user = await response.json();
    return Response.json({ connected: true, site: new URL(wpUrl).hostname, wordpressUser: user.name || wpUser, role: Array.isArray(user.roles) ? user.roles.join(", ") : "verified" }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Could not reach WordPress. Please try again." }, { status: 502 });
  }
};
